#ifndef MAILSASL_PRIVATE_H

#define MAILSASL_PRIVATE_H

#ifdef __cplusplus
extern"C"{
#endif

extern void mailsasl_init_lock(void);

extern void mailsasl_uninit_lock(void);

#ifdef __cplusplus
}
#endif


#endif